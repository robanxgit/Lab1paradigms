using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace aspnetcoreapp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnPost()
        {
            double num1 = 0, num2 = 0;

            // Parse num1 and num2 inputs
            if (!string.IsNullOrEmpty(Request.Form["num1"]))
            {
                string input1 = Request.Form["num1"].ToString().Replace("°", ""); // Remove degree symbol if present
                double.TryParse(input1, out num1);
            }

            if (!string.IsNullOrEmpty(Request.Form["num2"]))
            {
                string input2 = Request.Form["num2"].ToString().Replace("°", ""); // Remove degree symbol if present
                double.TryParse(input2, out num2);
            }

            // Get the operation selected by the user
            string operation = Request.Form["operation"];

            // Perform the selected operation
            switch (operation)
            {
                case "ADD":
                    ViewData["result"] = num1 + num2;
                    break;
                case "SUBTRACT":
                    ViewData["result"] = num1 - num2;
                    break;
                case "MULTIPLY":
                    ViewData["result"] = num1 * num2;
                    break;
                case "SQUARE":
                    ViewData["result"] = num1 * num1;
                    break;
                case "CUBE":
                    ViewData["result"] = num1 * num1 * num1;
                    break;
                case "SIN":
                    ViewData["result"] = Math.Sin(num1 * Math.PI / 180); // Convert degrees to radians
                    break;
                case "COS":
                    ViewData["result"] = Math.Cos(num1 * Math.PI / 180); // Convert degrees to radians
                    break;
                default:
                    ViewData["error"] = "Invalid operation or missing input!";
                    break;
            }
        }
    }
}
