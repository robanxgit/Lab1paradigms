﻿//2. Tail-recursive function to calculate the product of all elements in a list
let rec productTailRec (lst: int list) (acc: int) : int =
    match lst with
    | [] -> acc  
    | head :: tail -> productTailRec tail (acc * head)  

// Wrapper function for productTailRec
let product (lst: int list) : int =
    productTailRec lst 1 

// List of integers for product calculation
let numbers : int list = [1; 2; 3; 4; 5]
let productResult : int = product numbers  // Using the correct type
printfn "(Answer 2. Tail Recursion 1) The product of all elements is: %d" productResult




//3. Tail-recursive function to calculate the product of all odd numbers from n to 1
let rec productOddTailRec (n: int) (acc: int) : int =
    if n < 1 then acc  // Return the accumulated product when n is less than 1
    else if n % 2 <> 0 then productOddTailRec (n - 2) (acc * n)  // Multiply and recurse for odd n
    else productOddTailRec (n - 1) acc  // Skip even numbers

// Example usage for n = 11
let oddProductResult : int = productOddTailRec 11 1  // Explicit type annotation for oddProductResult
printfn "(Answer 3. Tail Recursion 2) The product of odd numbers from 11 to 1 is: %d" oddProductResult



 //4. Using Map Function with a Collection:

let nameList: string list = ["komal"; "Roban "; "Mandeep"; "Nancy"]

let trimmedNames = List.map (fun (name: string) -> name.Trim()) nameList

printfn "(Answer 4.)Trimmed Names: %A" trimmedNames



//5. Using Filter and Reduce with a Collection

let sequence = [1..700]                                   
let filtered = List.filter (fun x -> x % 7 = 0 && x % 5 = 0) sequence
let sum = List.reduce (+) filtered

printfn "(Answer 5.)Sum of multiples of 7 and 5: %d" sum



 //6. Using Filter and Reduce with Collection of Strings

let names: string list = ["Robin"; "Roban"; "Nincy"; "Isha"; "Indermeet"; "Diwali"; "Diljit"]

let filteredNames = List.filter (fun (name: string) -> name.ToLower().Contains("i")) names

let concatenatedNames = List.reduce (+) filteredNames

printfn "(Answer 6.)Concatenated Names: %s" concatenatedNames




