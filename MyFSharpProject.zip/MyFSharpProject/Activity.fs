let double = fun x -> * 2
let x = double 5
printfn "%A" x


// second activity
let  curriedAdd x y = x+y
printfn "%A" (curriedAdd 5  10)

let toupleAdd (x,y) = x+y
printfn "%A" (toupleAdd (10, 5))

// Third function
let something x y =
    let doubleX = x * 2
    let doubleY = y * 2
    doubleX + doubleY

let value = something 5 6
printfn "%A" value

// fourth activity 
let print x=
    printfn "%s" x 
"Hello, My name is Robaniyaa" |> print
print<|   "Hello, My name is Robaniyaa"  
//
let doublex x = x*2
let triplex x = x*3
let increasebyone x =  x+1
let value = 10 |> increasebyone |> doublex |> triplex

printfn "%A" (value)
// composing funvtion
let doublex x = x*2
let triplex x = x*3
let increasebyone x =  x+1
let value = 10 |> increasebyone |> doublex |> triplex

printfn "%A" (value)
// activity 
let rec factorial x =
    if x<1 then 1
    else
      x* factorial(x-1)
      
let res = factorial(6)  
printfn "%A" res   // recursion 
// let NumberAry = [|1;2;3;4|]

printfn "%A" NumberAry

printfn "%A" NumberAry.[2]

let newArray = Array.append NumberAry [|11;12;13|]

printfn "%A" NumberAry

printfn "%A" newArray

let newArray2 = NumberAry |> Array.append [|11;12;13|]

printfn "%A" NumberAry

printfn "%A" newArray2 // activity
//
let x = fun n -> n*n
let square = [2;3;4;5] |> List.map x

printfn "%A" square

let f = fun (s : string) -> s.Length
let newList = ["five"; "six"; "pick up"; "sticks"]
let lengths = newList |> List.map f
printfn "%A" lengths
// let nancy = [2;3;4;5]
nancy |> List.iter (printfn"%A")
// collection function
// FILTER FUNCTION
// reduce function 
